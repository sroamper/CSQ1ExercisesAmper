/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csq1exercise2.pkg3;

/**
 *
 * @author TRUTH
 */
public class Singer{
    String name;
    int noOfPerformances;
    double earnings;
    Song favoriteSong;
    int noOfPeople;
    
    public Singer(String name){
        this.name = name;

    }
    
    public void performForAudience(int noOfPeople){
        this.noOfPerformances++;
        this.earnings = earnings + 100 * noOfPeople;
        
    }
    
    public void changeFavSong(Song favoriteSong){
        this.favoriteSong = favoriteSong;
    }

}
