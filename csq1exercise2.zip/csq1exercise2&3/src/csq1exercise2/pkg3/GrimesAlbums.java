/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csq1exercise2.pkg3;

/**
 *
 * @author TRUTH
 */
public class GrimesAlbums {
    String name;
    String year;
    
    public GrimesAlbums(String name, String year){
       this.name = name;
       this.year = year;
    }
}
