/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csq1exercise2.pkg3;

/**
 *
 * @author TRUTH
 */
public class Csq1exercise23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        GrimesAlbums Visions = new GrimesAlbums("Visions", "2012");
        GrimesAlbums Art_Angels = new GrimesAlbums("Art Angels", "2015");
        GrimesAlbums Miss_Anthropocene = new GrimesAlbums("Miss Anthropocene", "2020");
        
        Song Oblivion =  new Song("Oblivion", "Grimes");
        Song Genesis = new Song("Genesis", "Grimes");
        Song Realiti = new Song("Realiti", "Grimes");
        
        Singer grimes = new Singer("Grimes");
        grimes.changeFavSong(Oblivion);
        grimes.performForAudience(12);
        grimes.changeFavSong(Genesis);
    }
    
}
