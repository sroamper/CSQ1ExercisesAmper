/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package csq1exercise4;
import java.util.Scanner;
/**
 *
 * @author TRUTH
 */
public class Csq1exercise4 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Move rock = new Move("Rock");
        Move paper = new Move("Paper");
        Move scissors = new Move("Scissors");

        rock.setStrongAgainst(scissors);
        paper.setStrongAgainst(rock);
        scissors.setStrongAgainst(paper);

        int roundsToWin = 2;
        Scanner scan = new Scanner(System.in);
        Move player = null, computer = null;
        System.out.print("Welcome to Rock, Paper, Scissors. Please choose an option:\n" +
"1. Start game\n" +
"2. Change number of rounds\n" +
"3. Exit application\n");
        String option = scan.nextLine();

        switch(option){
            case "1": 
                int compscore = 0;
                int playerscore = 0;
                while(roundsToWin<=2){ 
System.out.print("This match will be first to 2 wins.\n" +
"The computer has selected its move. Select your move:\n" +
"1. Rock\n" +
"2. Paper\n" +
"3. Scissors\n");

String move = scan.nextLine();
String moveReal = null;
    switch(move){
        case "1": player = rock;
        case "2": player = paper;
        case "3": player = scissors;
    }
    
int random = (int) Math.floor(Math.random()*3) + 1;
String moveComp = null;
    switch(random){
        case 1: computer = rock;
        case 2: computer = paper;
        case 3: computer = scissors;
    }
  int numResult = Move.compareMoves(player, computer);
   String result = "";
   switch(numResult){
        case 0: result = "wins";
        case 1: result = "loses";
        case 2: result = "draws with computer this";
    }

System.out.print("Player chose " + moveReal + ". Computer chose " + moveComp + ". Player " + result + " round!\n "
        + "Player: " + playerscore + " - Computer: " + compscore + "\n\n");
                
            }
            
            case "2": System.out.print("This match will be first to 2 wins.\n" +
"The computer has selected its move. Select your move:\n" +
"1. Rock\n" +
"2. Paper\n" +
"3. Scissors");
            
            case "3": System.out.print("This match will be first to 2 wins.\n" +
"The computer has selected its move. Select your move:\n" +
"1. Rock\n" +
"2. Paper\n" +
"3. Scissors");
            
            default: System.out.print("yooooo 1 to 3 kaseeeee");

        
        }
    }
    
}
