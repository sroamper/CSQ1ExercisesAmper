/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csq1exercise2.pkg3;

/**
 *
 * @author TRUTH
 */
public class Song {
    private String title, artist;
    
    public Song(String title, String artist){
       this.title = title;
       this.artist = artist;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return the artist
     */
    public String getArtist() {
        return artist;
    }
    
    
}
