/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csq1exercise2.pkg3;

/**
 *
 * @author TRUTH
 */
public class Singer{
    private String name;
    private int noOfPerformances;
    private static int totalPerformances = 0;
    private double earnings;
    private Song favoriteSong;

    
    public Singer(String name){
        this.name = name;
        this.noOfPerformances = 0;
        this.earnings = 0;
        this.favoriteSong = null;
    }
    
    public void performForAudience(int noOfPeople){
        this.noOfPerformances++;
        this.earnings = getEarnings() + 100 * noOfPeople;
        this.totalPerformances++;
        
    }
    
    public void performForAudience(Singer otherSinger, int noOfPeople){
        double revenue = noOfPeople*100;
        this.totalPerformances++;
        this.noOfPerformances++;
        this.earnings = getEarnings() + revenue/2;
        otherSinger.earnings += revenue/2;
        
    }
    
    public void changeFavSong(Song favoriteSong){
        this.setFavoriteSong(favoriteSong);
    }
    
    /**
     * @return the noOfPerformances
     */
    
    public int getNoOfPerformances() {
        return noOfPerformances;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
    
    /**
     * @return the earnings
     */
    public double getEarnings() {
        return earnings;
    }

    /**
     * @return the favoriteSong
     */
    public Song getFavoriteSong() {
        return favoriteSong;
    }

    /**
     * @param favoriteSong the favoriteSong to set
     */
    public void setFavoriteSong(Song favoriteSong) {
        this.favoriteSong = favoriteSong;
    }
    
    
    

}
